Stripe Integration - Quickstart
1. Create products/prices in Stripe dashboard.
2. Set STRIPE_SECRET env var for backend.
3. Use /api/v1/subscribe to create a subscription: backend should create a Stripe Customer and Subscription.
Example server-side (Node/Express) pseudo-code:

const stripe = require('stripe')(process.env.STRIPE_SECRET);
app.post('/api/v1/subscribe', async (req, res) => {
  const { userId, priceId } = req.body;
  // create or retrieve customer linked to userId
  const customer = await stripe.customers.create({ metadata: { userId } });
  const subscription = await stripe.subscriptions.create({
    customer: customer.id,
    items: [{ price: priceId }],
    payment_behavior: 'default_incomplete',
    expand: ['latest_invoice.payment_intent'],
  });
  res.json(subscription);
});

Webhooks:
- Configure endpoint /api/v1/webhooks/stripe and verify signature with stripe.webhooks.constructEvent(payload, sig, endpointSecret)
- Handle events: invoice.paid, invoice.payment_failed, customer.subscription.deleted, checkout.session.completed

Security:
- Store Stripe webhook secret in env STRIPE_WEBHOOK_SECRET
