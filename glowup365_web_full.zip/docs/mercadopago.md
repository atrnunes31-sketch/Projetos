MercadoPago Integration - Quickstart
1. Create your MercadoPago credentials (access token) in MercadoPago dashboard.
2. Use MercadoPago Checkout or Preference API to create payment preferences.
3. Backend should verify payment notifications (webhooks) from MercadoPago.
Example:
- Create preference with items and back_urls.
- Handle notifications to confirm payment and activate subscription in your DB.

Security:
- Store MercadoPago access token in env MP_ACCESS_TOKEN
