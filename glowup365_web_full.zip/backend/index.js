const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const upload = multer({ dest: 'uploads/' });
app.use(bodyParser.json());
app.use(cors());

app.post('/api/v1/auth/signup', (req, res) => {
  const { name, email } = req.body;
  res.status(201).json({ id: 'user_123', name, email });
});

app.post('/api/v1/onboarding', (req, res) => {
  const payload = req.body;
  const plan = {
    plan_name: 'Trim 30',
    weekly_schedule: [
      { day: 'Mon', type: 'HIIT', duration: 20 },
      { day: 'Wed', type: 'Resistance', duration: 30 },
      { day: 'Fri', type: 'FullBody', duration: 30 }
    ]
  };
  res.json({ plan });
});

app.get('/api/v1/workouts/today', (req, res) => {
  res.json({ workouts: [{ id: 'w1', name: 'HIIT 20', duration: 20 }] });
});

app.post('/api/v1/workouts/:id/complete', (req, res) => {
  res.json({ ok: true, id: req.params.id });
});

app.post('/api/v1/photos', upload.single('photo'), (req, res) => {
  res.status(201).json({ url: '/uploads/' + req.file.filename });
});

app.post('/api/v1/subscribe', (req, res) => {
  res.json({ ok: true, subscriptionId: 'sub_123' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Backend running on port', PORT));

// Stripe webhook example (verify signature)
const stripe = require('stripe')(process.env.STRIPE_SECRET || '');
app.post('/api/v1/webhooks/stripe', express.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    // Handle the event
    if (event.type === 'invoice.paid') {
      // mark subscription active in DB
    } else if (event.type === 'invoice.payment_failed') {
      // notify user
    }
    res.json({received: true});
  } catch (err) {
    console.error('Webhook Error:', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});
