import React from 'react';

export default function Plans(){
  return (
    <div style={{padding:24}}>
      <h2>Planos</h2>
      <div className="plans">
        <div className="plan"><h3>Grátis</h3><p>Acesso básico</p></div>
        <div className="plan"><h3>Básico</h3><p>R$19,90/mês</p></div>
        <div className="plan"><h3>Pro</h3><p>R$39,90/mês</p></div>
      </div>
    </div>
  );
}
