import React from 'react';

export default function Dashboard(){
  const [workouts, setWorkouts] = React.useState([]);
  React.useEffect(()=>{fetch('http://localhost:3000/api/v1/workouts/today').then(r=>r.json()).then(d=>setWorkouts(d.workouts))},[]);
  return (
    <div style={{padding:24}}>
      <h2>Dashboard</h2>
      <h3>Treino do dia</h3>
      <ul>{workouts.map(w=> <li key={w.id}>{w.name} - {w.duration} min</li>)}</ul>
    </div>
  );
}
