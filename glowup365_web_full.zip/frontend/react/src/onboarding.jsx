import React, {useState} from 'react';

export default function Onboarding(){
  const [form, setForm] = useState({name:'',age:'',weight:'',height:'',objectives:[]});
  function handleChange(e){
    const {name, value} = e.target;
    setForm({...form, [name]: value});
  }
  async function submit(){
    await fetch('http://localhost:3000/api/v1/onboarding', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form)});
    alert('Plano gerado! (verifique backend)');
  }
  return (
    <div style={{padding:24}}>
      <h2>Onboarding</h2>
      <input name="name" placeholder="Nome" onChange={handleChange} /><br/><br/>
      <input name="age" placeholder="Idade" onChange={handleChange} /><br/><br/>
      <input name="weight" placeholder="Peso (kg)" onChange={handleChange} /><br/><br/>
      <input name="height" placeholder="Altura (cm)" onChange={handleChange} /><br/><br/>
      <button onClick={submit}>Enviar</button>
    </div>
  );
}
