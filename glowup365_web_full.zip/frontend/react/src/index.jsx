import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import './styles.css';
import Onboarding from './onboarding';
import Dashboard from './dashboard';
import Plans from './plans';

function App(){
  return (
    <BrowserRouter>
      <header className="hero">
        <h1>GlowUp365</h1>
        <nav>
          <Link to="/">Home</Link> | <Link to="/onboarding">Onboarding</Link> | <Link to="/dashboard">Dashboard</Link> | <Link to="/plans">Planos</Link>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<div style={{padding:24}}><h2>Bem-vindo ao GlowUp365</h2><p>Seu coach diário para corpo e rosto.</p></div>} />
        <Route path="/onboarding" element={<Onboarding/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/plans" element={<Plans/>} />
      </Routes>
    </BrowserRouter>
  );
}

const root = createRoot(document.getElementById('root'));
root.render(<App />);
